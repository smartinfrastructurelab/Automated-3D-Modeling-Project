
class MatchingEngine():
    outputFileName = "matches.init.txt"
    featureExtractionNeeded = True

    def __init__(self):
        pass

    def match(self):
        pass