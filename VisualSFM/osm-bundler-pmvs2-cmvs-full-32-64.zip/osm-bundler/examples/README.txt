Photoset comes from Bundler GNU package.
http://phototour.cs.washington.edu/bundler/